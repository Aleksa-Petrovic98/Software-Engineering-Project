﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;
namespace library
{
    class Program
    {
        const string CONFIGFILEPATH = "configfile.txt";
        static bool verifyLoginCredentials(List<User> users, string username)
        {

            string password;
            for (int i = 0; i < users.Count; ++i)
            {
                if (username.Equals(users[i].LoginUserName))
                {
                    Console.WriteLine("Please enter your password: ");
                    password = Console.ReadLine();
                    if (password.Equals(users[i].Password))
                    {
                        Console.WriteLine("Login succesful");
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("Credentials incorrect please try again: ");
                        return false;
                    }
                }
            }
            Console.WriteLine("We couldn't find the login username please try again");
            return false;

        }
        static string loginSystem(List<User> users, int maxAttempts)
        {
            Console.WriteLine("Please enter your login username: ");
            string username = Console.ReadLine();
            //Check if login credentials are accurate and in the system if so return username so we keep track of who is logged in
            int count = 0;

            while (!verifyLoginCredentials(users, username))
            {
                username = Console.ReadLine();

                if (count >= maxAttempts - 1)
                {
                    Console.WriteLine("You have reached the maximum number of login attempts please try again later. Press anything to exit");
                    Console.ReadKey();
                    return null;
                }
                count++;
            }
            return username;
        }
        static string passwordCreation()
        {
            Console.WriteLine("Please chose your password: ");
            string password = Console.ReadLine();
            while (true)
            {
                Console.WriteLine("Please repeat your password: ");
                string passwordAuth = Console.ReadLine();

                if (!password.Equals(passwordAuth))
                {
                    Console.WriteLine("Passwords do not match");
                    Console.WriteLine("Press 0 to exit or any other key to input password again");

                    if (Console.ReadKey().Equals(0)) break;
                    else Console.WriteLine();

                    Console.WriteLine("Please chose your password");
                    password = Console.ReadLine();
                }
                else return password;
            }
            return password;
        }
        static Boolean emailRegex(string email)
        {
            Regex rx = new Regex((@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"));
            if (rx.Match(email).Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static bool checkIfEmailTaken(string email, string userInfoPath)
        {
            List<User> users = Load(userInfoPath);
            for (int i = 0; i < users.Count; ++i)
            {
                if (email.Equals(users[i].Email))
                {
                    Console.WriteLine("Email is taken: ");
                    return false;
                }
            }
            return true;
        }
        static bool checkIfLoginNameTaken(string loginName, string userInfoPath)
        {
            List<User> users = Load(userInfoPath);
            for (int i = 0; i < users.Count; ++i)
            {
                if (loginName.Equals(users[i].LoginUserName))
                {
                    Console.WriteLine("User name is taken: ");
                    return false;
                }
            }
            return true;
        }

        static User createUser(bool admin, string userInfoPath)
        {
            string firstName, lastName, loginUserName, password, email;
            int age;

            Console.WriteLine("Please enter first name of user: ");
            firstName = Console.ReadLine();

            Console.WriteLine("Please enter last name of user: ");
            lastName = Console.ReadLine();

            Console.WriteLine("Please enter users login name:  ");
            loginUserName = Console.ReadLine();
            while (!checkIfLoginNameTaken(loginUserName, userInfoPath))
            {
                Console.WriteLine("Please enter your Login username:  ");
                loginUserName = Console.ReadLine();
            }
            Console.WriteLine("Please enter your email: ");
            email = Console.ReadLine();
            while (!emailRegex(email) || !checkIfEmailTaken(email, userInfoPath))
            {
                Console.WriteLine("Invalid email, please try again");
                Console.WriteLine("Please enter your email: ");
                email = Console.ReadLine();
            }

            Console.WriteLine("Please enter users age: ");
            age = intInputEnforcer();

            password = passwordCreation();  //Makes sure user authenticates password
            Console.WriteLine("Is user admin? Write yes or no");
            string answer = Console.ReadLine().ToLower();
            if (answer.Equals("yes"))
            {
                Console.WriteLine("User succesfully created");
                return new User(firstName, lastName, age, loginUserName, password, email, true);
            }
            else
            {
                Console.WriteLine("User succesfully created");
                return new User(firstName, lastName, age, loginUserName, password, email, false);
            }

        }

        static bool createAdmin(string username, string password, List<User> users, string userInfoPath)
        {
            //Check to see if there is already an admin account in the file if not creates it
            for (int i = 0; i < users.Count; ++i)
            {
                if (users[i].LoginUserName.Equals("admin"))
                {
                    return false;
                }
            }
            User admin = new User(username, password);
            Save(userInfoPath, admin);
            return true;

        }
        public static void printUser(User user)
        {
            Console.WriteLine(user.FirstName);
            Console.WriteLine(user.LastName);
            Console.WriteLine(user.Age);
            Console.WriteLine(user.LoginUserName);
            Console.WriteLine(user.Password);
            Console.WriteLine(user.Admin);
        }
        public static List<User> Load(string fileName)
        {
            List<User> users = new List<User>();

            using (Stream fileStream = File.Open(fileName, FileMode.Open))
            {
                if (fileStream.Length != 0)
                {
                    BinaryFormatter bfd = new BinaryFormatter();
                    while (fileStream.Position != fileStream.Length)
                    {
                        users.Add((User)bfd.Deserialize(fileStream));
                    }
                    return users;
                }
            }
            return users;
        }
        public static void Save(string file, User user)
        {
            using (FileStream fileWrite = new FileStream(file, FileMode.Append))
            {
                BinaryFormatter bf = new BinaryFormatter();

                bf.Serialize(fileWrite, user);
                fileWrite.Close();
            }
        }
        static int intInputEnforcer()
        {
            while (true)
            {
                int num = 0;
                try
                {
                    num = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("You must write a number");
                }
                if (num != 0)
                {
                    return num;
                }
            }
        }
        static List<Book> fileToBookList(string fileName)
        {
            StreamReader bookList = new StreamReader(fileName);
            List<Book> books = new List<Book>();
            while (!bookList.EndOfStream)
            {
                string title = bookList.ReadLine().Split(':')[1];
                string author = bookList.ReadLine().Split(':')[1];
                string publisher = bookList.ReadLine().Split(':')[1];
                int year = int.Parse(bookList.ReadLine().Split(':')[1]); // We don't need checks if its int because we have them when inputing in the file
                int month = int.Parse(bookList.ReadLine().Split(':')[1]);
                string genre = bookList.ReadLine().Split(':')[1]; ;
                int isbn = int.Parse(bookList.ReadLine().Split(':')[1]);

                books.Add(new Book(title, author, publisher, year, month, genre, isbn));

            }
            bookList.Close();
            return books;
        }
        static List<Book> filterByGenre(List<Book> books, string bookGenre)
        {
            List<Book> booksByGenre = new List<Book>();

            for (int i = 0; i < books.Count; ++i)
            {
                if (books[i].Genre.ToLower().Equals(bookGenre.ToLower()))
                {
                    booksByGenre.Add(books[i]);
                }
            }
            return booksByGenre;
        }
        static Book createBook()
        {

            Console.WriteLine("Title name: ");
            string title = Console.ReadLine();

            Console.WriteLine("Author name: ");
            string author = Console.ReadLine();

            Console.WriteLine("Publisher name: ");
            string publisher = Console.ReadLine();

            Console.WriteLine("Year published : ");
            int inputYear = intInputEnforcer();
            int year;
            while (!yearInputEnforcer(inputYear, 2021))
            {
                Console.WriteLine("Please write a valid year (number from 0 to current year)");
                Console.WriteLine("Year published : ");
                inputYear = intInputEnforcer();
            }

            year = inputYear;

            Console.WriteLine("Month published: ");
            int inputMonth = intInputEnforcer();
            int month;
            while (!monthInputEnforcer(inputMonth))
            {
                Console.WriteLine("Please write a valid year (number from 0 to 12)");
                Console.WriteLine("Month published : ");
                inputMonth = intInputEnforcer();
            }
            month = inputMonth;
            Console.WriteLine("Genre of the book: ");
            string genre = Console.ReadLine();

            Console.WriteLine("ISBN of the book: ");
            int ISBN = intInputEnforcer();

            return new Book(title, author, publisher, year, month, genre, ISBN);
        }
        static void writeRentingInfoToFile(string username, int isbn, string fileName)
        {

            StreamWriter outputFile = new StreamWriter(fileName, append: true);
            outputFile.WriteLine(username + " " + isbn);
            outputFile.Close();
        }
        static Dictionary<String, String> loadFromConfigFile(string filename)
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();

            using (StreamReader sr = File.OpenText(filename))
            {
                string[] line;
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine().Split(':');
                    dict.Add(line[0], line[1]);
                }
            }
            return dict;
        }
        static bool monthInputEnforcer(int num)
        {
            return (num < 1 || num > 12) ? false : true;
        }
        static bool yearInputEnforcer(int num, int currentYear)
        {
            //This library does not have any books that are B.C.
            return (num < 1 || num > currentYear) ? false : true;

        }
        static void writeBookToFile(Book book, string fileName)
        {
            StreamWriter outputFile = new StreamWriter(fileName, append: true);
            outputFile.WriteLine("Title:" + book.Title);
            outputFile.WriteLine("Author:" + book.Author);
            outputFile.WriteLine("Publisher:" + book.Publisher);
            outputFile.WriteLine("Year:" + book.Year);
            outputFile.WriteLine("Month:" + book.Month);
            outputFile.WriteLine("Genre:" + book.Genre);
            outputFile.WriteLine("ISBN:" + book.ISBN);
            outputFile.Close();

        }
        static void listBooks(string fileName)
        {
            StreamReader bookList = new StreamReader(fileName);
            while (!bookList.EndOfStream)
            {
                Console.WriteLine(bookList.ReadLine());
            }
        }
        static int findBookISBNFromBookTitle(List<Book> books, string bookTitle)
        {
            for (int i = 0; i < books.Count; ++i)
            {
                if (books[i].Title.ToLower().Equals(bookTitle.ToLower()))
                {
                    return books[i].ISBN;
                }
            }
            return 0;
        }
        static void checkIfFullInfo(string word, List<Book> books)
        {
            if (word.ToLower().Equals("full"))
            {
                printBooks(books);
            }
            else
            {
                printBooksByTitle(books);
            }
        }
        static void displayBooksByTitle(List<Book> availableBooks, string username, string rentInfoFile, string availableBookFile, string userInfoPath, string bookFile, bool admin)
        {
            Console.WriteLine("Write the title of the book you want to see: ");
            string bookTitle = Console.ReadLine();
            int isbn;
            if (searchByTitle(availableBooks, bookTitle))
            {
                Console.WriteLine("Do you want to rent this book? Write yes to rent or press enter to continue");
                string answer = Console.ReadLine().ToLower();
                if (answer.Equals("yes"))
                {
                    isbn = findBookISBNFromBookTitle(availableBooks, bookTitle);

                    if (isbn >= 1)
                    {
                        writeRentingInfoToFile(username, isbn, rentInfoFile);
                        removeBook(availableBooks, availableBookFile, isbn);
                        Console.WriteLine("You have rented this book");
                    }
                    else
                    {
                        Console.WriteLine("Could not rent book please check ISBN and try again");
                    }
                }
            }
            else
            {
                Console.WriteLine("Sorry we couldn't find your book");
                Console.WriteLine("Press 0 to go back to main menu: ");
                if (Console.ReadLine().Equals("0")) listOfOptions(availableBookFile, userInfoPath, username, bookFile, rentInfoFile, admin);
            }
        }
        static void listOfOptions(string availableBookFile, string userInfoPath, string username, string bookFile, string rentInfoFile, bool admin)
        {
            //Essentially a main menu of the application
            string nameOfFile = availableBookFile; // save so we can go back to main menu

            if (admin)
            {
                Console.WriteLine("1. Add a book");
                Console.WriteLine("2. Remove a book");
                Console.WriteLine("3. List all the books");
                Console.WriteLine("4. Search by genre");
                Console.WriteLine("5. List users");
                Console.WriteLine("6. Create a user");
                Console.WriteLine("7. View books rented");
                Console.WriteLine("8. Return a book");
                string key = Console.ReadLine();
                List<Book> availableBooks = fileToBookList(availableBookFile);
                List<Book> books = fileToBookList(bookFile);
                Dictionary<string, List<Book>> dict = rentFileToDict(rentInfoFile, books);
                switch (key)
                {
                    case "1":
                        Book book = createBook();
                        writeBookToFile(book, availableBookFile);
                        writeBookToFile(book, bookFile);
                        break;

                    case "2":
                        Console.WriteLine("Please write ISBN of the book you want to remove");
                        removeBook(availableBooks, availableBookFile, intInputEnforcer());
                        break;

                    case "3":
                        Console.WriteLine("Write 'alpha' to sort alphabetically, 'year' to sort by year or press enter to view unsorted");
                        string responseForSort = Console.ReadLine();
                        Console.WriteLine("Write 'full' if you want to view full information of the books or press enter to just browse by title");
                        string responseForFull = Console.ReadLine();
                        if (responseForSort.ToLower().Equals("alpha"))
                        {
                            List<Book> sortedByAlphabet = availableBooks;
                            sortedByAlphabet.Sort((x, y) => x.Title.CompareTo(y.Title));
                            checkIfFullInfo(responseForFull, sortedByAlphabet);

                        }
                        else if (responseForSort.ToLower().Equals("year"))
                        {
                            List<Book> sortedByYear = availableBooks;
                            sortedByYear.Sort((x, y) => x.Year.CompareTo(y.Year));
                            checkIfFullInfo(responseForFull, sortedByYear);

                        }
                        else
                        {
                            checkIfFullInfo(responseForFull, availableBooks);
                        }

                        displayBooksByTitle(availableBooks, username, rentInfoFile, availableBookFile, userInfoPath, bookFile, admin);

                        break;
                    case "4":
                        Console.WriteLine("Write the genre you want to browse: ");
                        string genre = Console.ReadLine();
                        List<Book> bookByGenre = filterByGenre(availableBooks, genre);
                        if (bookByGenre.Count > 0)
                        {
                            printBooksByTitle(bookByGenre);
                            displayBooksByTitle(availableBooks, username, rentInfoFile, availableBookFile, userInfoPath, bookFile, admin);
                        }
                        else
                        {
                            Console.WriteLine("Sorry, this genre has not been found, please try again");
                        }

                        break;
                    case "5":
                        if (File.Exists(userInfoPath))
                        {
                            List<User> userDetails = Load(userInfoPath);
                            ViewUsers(userDetails);
                        }
                        break;
                    case "6":
                        Save(userInfoPath, createUser(admin, userInfoPath));
                        break;
                    case "7":
                        Console.WriteLine("List books you have rented");
                        listUserRentedBooks(dict, username);
                        break;
                    case "8":
                        Console.WriteLine("Write isbn of book you want to return");
                        returnBook(intInputEnforcer(), bookFile, availableBookFile, rentInfoFile);
                        break;

                }
                Console.WriteLine("Press 0 to go back to main menu: ");
                if (Console.ReadLine().Equals("0")) listOfOptions(availableBookFile, userInfoPath, username, bookFile, rentInfoFile, admin);
            }
            else
            {
                Console.WriteLine("1. List all the books");
                Console.WriteLine("2. Search by genre");
                Console.WriteLine("3. View books rented");
                Console.WriteLine("4. Return a book");
                string key = Console.ReadLine();
                List<Book> availableBooks = fileToBookList(availableBookFile);
                List<Book> books = fileToBookList(bookFile);
                Dictionary<string, List<Book>> dict = rentFileToDict(rentInfoFile, books);
                switch (key)
                {
                    case "1":
                        Console.WriteLine("Write alpha to sort alphabetically, year to sort by year or press enter to view unsorted");
                        string responseForSort = Console.ReadLine();
                        Console.WriteLine("Write full if you want to view full information of the books or press enter to just browse by title");
                        string responseForFull = Console.ReadLine();
                        if (responseForSort.ToLower().Equals("alpha"))
                        {
                            List<Book> sortedByAlphabet = availableBooks;
                            sortedByAlphabet.Sort((x, y) => x.Title.CompareTo(y.Title));
                            checkIfFullInfo(responseForFull, sortedByAlphabet);

                        }
                        else if (responseForSort.ToLower().Equals("year"))
                        {
                            List<Book> sortedByYear = availableBooks;
                            sortedByYear.Sort((x, y) => x.Year.CompareTo(y.Year));
                            checkIfFullInfo(responseForFull, sortedByYear);

                        }
                        else
                        {
                            checkIfFullInfo(responseForFull, availableBooks);
                        }

                        displayBooksByTitle(availableBooks, username, rentInfoFile, availableBookFile, userInfoPath, bookFile, admin);

                        break;
                    case "2":
                        Console.WriteLine("Write the genre you want to browse: ");
                        string genre = Console.ReadLine();
                        List<Book> bookByGenre = filterByGenre(availableBooks, genre);
                        if (bookByGenre.Count > 0)
                        {
                            printBooksByTitle(bookByGenre);
                            displayBooksByTitle(availableBooks, username, rentInfoFile, availableBookFile, userInfoPath, bookFile, admin);
                        }
                        else
                        {
                            Console.WriteLine("Sorry, this genre has not been found, please try again");
                        }

                        break;

                    case "3":
                        Console.WriteLine("List books you have rented");
                        listUserRentedBooks(dict, username);
                        break;
                    case "4":
                        Console.WriteLine("Write isbn of book you want to return");
                        returnBook(intInputEnforcer(), bookFile, availableBookFile, rentInfoFile);
                        break;


                }
                Console.WriteLine("Press 0 to go back to main menu: ");
                if (Console.ReadLine().Equals("0")) listOfOptions(availableBookFile, userInfoPath, username, bookFile, rentInfoFile, admin);
            }
        }
        static void removeBook(List<Book> books, string fileName, int isbn)
        {
            for (int i = 0; i < books.Count; ++i)
            {
                if (books[i].ISBN.Equals(isbn))
                {
                    books.RemoveAt(i);
                    Console.WriteLine("Book removed!");
                }
            }
            using (StreamWriter sw = File.CreateText(fileName))
            {
                sw.Flush();
                sw.Close();
            }
            for (int i = 0; i < books.Count; ++i)
            {
                writeBookToFile(books[i], fileName);
            }

        }
        static Boolean ifAdmin(List<User> users, string username)
        {
            for (int i = 0; i < users.Count; ++i)
            {
                if ((users[i].LoginUserName.ToLower()).Equals(username.ToLower()))
                {

                    return users[i].Admin;
                }
            }
            return false;
        }
        static Boolean searchByTitle(List<Book> books, string bookTitle)
        {
            for (int i = 0; i < books.Count; ++i)
            {
                if ((books[i].Title.ToLower()).Equals(bookTitle.ToLower()))
                {
                    books[i].printBook();
                    return true;
                }
            }
            return false;
        }
        static void printBooks(List<Book> books)
        {

            for (int i = 0; i < books.Count; i++)
            {
                Console.WriteLine("Title of the book : " + books[i].Title);
                Console.WriteLine("Author of the book : " + books[i].Author);
                Console.WriteLine("Publisher of the book : " + books[i].Publisher);
                Console.WriteLine("Year the book was written : " + books[i].Year);
                Console.WriteLine("Month the book was written : " + books[i].Month);
                Console.WriteLine("Genre of the book: " + books[i].Genre);
                Console.WriteLine("ISBN of the book: " + books[i].ISBN);
                Console.WriteLine();

            }
        }
        static Book findBookByISBN(int isbn, List<Book> books)
        {
            for (int i = 0; i < books.Count; ++i)
            {
                if (books[i].ISBN == isbn)
                {
                    return books[i];
                }
            }
            return null;

        }
        static void printBooksByTitle(List<Book> books)
        {
            for (int i = 0; i < books.Count; i++)
            {
                Console.WriteLine("'" + books[i].Title + "'");


            }
        }
        static void checkFileExistence(string file1name, string file2name, string file3name, string file4name)
        {
            FileStream f = File.Open(file1name, FileMode.Append);
            FileStream f2 = File.Open(file2name, FileMode.Append);
            FileStream f3 = File.Open(file3name, FileMode.Append);
            FileStream f4 = File.Open(file4name, FileMode.Append);

            f.Close();
            f2.Close();
            f3.Close();
            f4.Close();
        }

        static Dictionary<string, List<Book>> rentFileToDict(string fileName, List<Book> books)
        {
            Dictionary<string, List<Book>> dict = new Dictionary<string, List<Book>>();
            StreamReader fileWithRentInfo = new StreamReader(fileName);

            string username = "";
            int isbn;

            while (!fileWithRentInfo.EndOfStream)
            {
                string[] arr = fileWithRentInfo.ReadLine().Split(' ');
                username = arr[0];


                isbn = int.Parse(arr[1]);


                Book book = findBookByISBN(isbn, books);

                if (book != null)
                {
                    if (dict.ContainsKey(username))
                    {
                        List<Book> booksRented = dict[username];
                        booksRented.Add(book);
                        dict[username] = booksRented;
                    }
                    else
                    {
                        List<Book> tempBook = new List<Book>();
                        tempBook.Add(book);
                        dict.Add(username, tempBook);
                    }
                }
            }

            fileWithRentInfo.Close();
            return dict;
        }
        static void deleteRentedBook(int isbn, string rentedBookFile)
        {
            //Read file in string array split for title and isbn
            //if isbn matches in file dont write thta line to new file
            string[] fileLines = File.ReadAllLines(rentedBookFile);
            File.Delete(rentedBookFile);

            using (StreamWriter sw = File.AppendText(rentedBookFile))
            {
                foreach (string line in fileLines)
                {
                    string[] arr = line.Split(' ');

                    if (int.Parse(arr[1]) == isbn)
                    {
                        continue;
                    }
                    else
                    {
                        sw.WriteLine(line);
                    }
                }
            }
        }
        static void returnBook(int isbn, string bookFile, string availableBookFile, string rentedBookFile)
        {
            List<Book> books = fileToBookList(bookFile);
            if (books.Count > 1)
            {
                Book book = findBookByISBN(isbn, books);
                writeBookToFile(book, availableBookFile);
                deleteRentedBook(isbn, rentedBookFile);
            }
        }
        static void listUserRentedBooks(Dictionary<string, List<Book>> dict, string username)
        {

            foreach (var pair in dict)
            {
                if (pair.Key.Equals(username))
                {

                    List<Book> tempBooks = pair.Value;


                    for (int i = 0; i < tempBooks.Count; ++i)
                    {
                        Console.WriteLine("Title: " + tempBooks[i].Title);
                        Console.WriteLine("Book ISBN: " + tempBooks[i].ISBN);
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            //Check to see if files exist and if not create them
            Dictionary<string, string> configInfo = loadFromConfigFile(CONFIGFILEPATH);

            configInfo.TryGetValue("AvailableBooksFilePath", out string availableBooksPath);
            configInfo.TryGetValue("UserInfoFilePath", out string userInfoPath);
            configInfo.TryGetValue("BooksFilePath", out string booksFilePath);
            configInfo.TryGetValue("RentInfoFilePath", out string rentInfoPath);
            configInfo.TryGetValue("MaxLoginAttempts", out string maxLoginAttempts);

            checkFileExistence(userInfoPath, rentInfoPath, booksFilePath, availableBooksPath);
            List<User> users = Load(userInfoPath);

            string username;
            bool admin;
            if (createAdmin("admin", "nimda", users, userInfoPath))
            {
                username = "admin";
                admin = true;

            }
            else
            {
                username = loginSystem(users, int.Parse(maxLoginAttempts));
                if (username == null) Environment.Exit(0);
                Console.WriteLine("User logged in: " + username);
                admin = ifAdmin(users, username);
            }

            listOfOptions(availableBooksPath, userInfoPath, username, booksFilePath, rentInfoPath, admin);

            Console.ReadKey();
            Console.WriteLine("press any button to exit");
            Console.ReadKey();
        }

        static Book viewBook(List<Book> books, int isbn)
        {
            for (int i = 0; i < books.Count; ++i)
            {
                if (books[i].ISBN.Equals(isbn))
                {
                    return books[i];
                }
            }
            return null;
        }
        static void ViewUsers(List<User> userList)

        {
            for (int i = 0; i < userList.Count; i++)
            {
                Console.WriteLine("First name: " + userList[i].FirstName);
                Console.WriteLine("Last name: " + userList[i].LastName);
                Console.WriteLine("Login user name : " + userList[i].LoginUserName);
                Console.WriteLine("User age: " + userList[i].Age);
                Console.WriteLine("User password: " + userList[i].Password);
                Console.WriteLine("User email: " + userList[i].Email);
                Console.WriteLine("User admin: " + userList[i].Admin);
            }
        }
    }
}