﻿using System;
[Serializable()]
public class User
{
    private string firstName, lastName, loginUserName, password, email;
    private int age;
    private Boolean admin;
    //Constructor with parameters
    public User(string firstName, string lastName, int age, string loginUserName, string password, string email, Boolean admin)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.loginUserName = loginUserName;
        this.password = password;
        this.age = age;
        this.email = email;
        this.admin = admin;


    }
    public User(string loginUserName, string password)
    {
        this.loginUserName = loginUserName;
        this.password = password;
        firstName = "Admin";
        lastName = "Nimda";

        age = 0;
        admin = true;
    }

    public User()
    //Constructor with no params that init everything to default values
    {
        firstName = "default";
        lastName = "default";
        loginUserName = "default";
        age = 0;
        password = "default";
        admin = false;


    }



    //Getter and Setter methods for User class
    public string FirstName { get => firstName; set => firstName = value; }
    public string LastName { get => lastName; set => lastName = value; }
    public string LoginUserName { get => loginUserName; set => loginUserName = value; }
    public string Password { get => password; set => password = value; }
    public int Age { get => age; set => age = value; }

    public string Email { get => email; set => email = value; }
    public bool Admin { get => admin; set => admin = value; }
}
