﻿using System;

namespace library
{
    class Book
    {
        private string title, author, publisher, genre;
        private int year, month, isbn;

        public Book(string title, string author, string publisher, int year, int month, string genre, int isbn)
        {
            this.title = title;
            this.author = author;
            this.publisher = publisher;
            this.year = year;
            this.month = month;
            this.genre = genre;
            this.isbn = isbn;
        }
        public void printBook()
        {
            Console.WriteLine("Title of the book : " + title);
            Console.WriteLine("Author of the book : " + author);
            Console.WriteLine("Publisher of the book : " + publisher);
            Console.WriteLine("Year the book was written : " + year);
            Console.WriteLine("Month the book was written : " + month);
            Console.WriteLine("Genre of the book: " + genre);
            Console.WriteLine("ISBN of the book: " + ISBN);
        }

        public string Title { get => title; set => title = value; }
        public string Author { get => author; set => author = value; }
        public string Publisher { get => publisher; set => publisher = value; }
        public int Month { get => month; set => month = value; }
        public int Year { get => year; set => year = value; }

        public string Genre { get => genre; set => genre = value; }
        public int ISBN { get => isbn; set => isbn = value; }
    }
}
